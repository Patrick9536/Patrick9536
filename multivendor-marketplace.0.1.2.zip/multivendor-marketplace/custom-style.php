<?php

	$multivendor_marketplace_custom_css= "";

	/*-------------------- Global Color First Color-------------------*/

	$multivendor_marketplace_first_color = get_theme_mod('multivendor_marketplace_first_color');

	if($multivendor_marketplace_first_color != false){
		$multivendor_marketplace_custom_css .='.middle-header .search-box button,#slider .carousel-control-next i, #slider .carousel-control-prev i,.scrollup i,.woocommerce span.onsale,#footer-2,.woocommerce span.onsale,#comments input[type="submit"], #comments a.comment-reply-link, input[type="submit"], .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .pro-button a, .woocommerce a.added_to_cart.wc-forward,nav.woocommerce-MyAccount-navigation ul li,.view-btn a, #slider .more-btn a, .more-btn a, #footer .wp-block-search .wp-block-search__button, #sidebar .wp-block-search .wp-block-search__button, #sidebar h3, #sidebar .widget_block h3, #sidebar h2{';
			$multivendor_marketplace_custom_css .='background: '.esc_attr($multivendor_marketplace_first_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	if($multivendor_marketplace_first_color != false){
		$multivendor_marketplace_custom_css .='.woocommerce-message::before, .woocommerce-info::before,.main-navigation li a:hover, .main-navigation li a:focus, .main-navigation ul ul a:focus, .main-navigation ul ul a:hover,#slider .carousel-control-next i:hover, #slider .carousel-control-prev i:hover,.top-bar a:hover, .top-bar .social-icons .widget a:hover, .account a:hover, .cart_no a:hover, .wishlist a:hover, p.phone_no a:hover,p.site-title a:hover, .logo h1 a:hover,.wp-block-quote, .wp-block-quote:not(.is-large):not(.is-style-large), .wp-block-pullquote,.woocommerce-account .woocommerce-MyAccount-content a, .woocommerce-info a, .woocommerce-privacy-policy-text a, .woocommerce-cart-form__cart-item cart_item a,.wp-block-latest-comments a,.post-main-box:hover h2 a, .post-main-box:hover .post-info span a, .single-post .post-info:hover a, .middle-bar h6, .entry-content a, .widget_text a, .woocommerce-page .entry-summary a, .comment-content p a,#slider .slider-btn a,#slider .inner_carousel h1 a:hover, .banner-content a:hover, .seller-banner-content h3 a:hover{';
			$multivendor_marketplace_custom_css .='color: '.esc_attr($multivendor_marketplace_first_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	if($multivendor_marketplace_first_color != false){
		$multivendor_marketplace_custom_css .='.wp-block-quote, .wp-block-quote:not(.is-large):not(.is-style-large), .wp-block-pullquote,.woocommerce-message, .woocommerce-info{';
			$multivendor_marketplace_custom_css .='border-color: '.esc_attr($multivendor_marketplace_first_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_custom_css .='@media screen and (max-width:1000px) {';
		if($multivendor_marketplace_first_color != false){
			$multivendor_marketplace_custom_css .='.main-navigation a:hover{
				color:'.esc_attr($multivendor_marketplace_first_color).' !important;
			}';
		}
	$multivendor_marketplace_custom_css .='}';


	/*-------------------- Global Color Second Color-------------------*/
	$multivendor_marketplace_second_color = get_theme_mod('multivendor_marketplace_second_color');

	if($multivendor_marketplace_second_color != false){
		$multivendor_marketplace_custom_css .='.top-bar, .middle-header, .view-btn a:hover,.control-section-multivendor-marketplace h3.accordion-section-title,.bradcrumbs a,.bradcrumbs span ,#preloader{';
			$multivendor_marketplace_custom_css .='background: '.esc_attr($multivendor_marketplace_second_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	if($multivendor_marketplace_second_color != false){
		$multivendor_marketplace_custom_css .='.woocommerce div.product p.price, .woocommerce div.product span.price, .woocommerce ul.products li.product .price,del span.woocommerce-Price-amount.amount bdi{';
			$multivendor_marketplace_custom_css .='color: '.esc_attr($multivendor_marketplace_second_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	/*---------------------------Width Layout -------------------*/

	$multivendor_marketplace_theme_lay = get_theme_mod( 'multivendor_marketplace_width_option','Full Width');
    if($multivendor_marketplace_theme_lay == 'Boxed'){
		$multivendor_marketplace_custom_css .='body{';
			$multivendor_marketplace_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$multivendor_marketplace_custom_css .='}';
		$multivendor_marketplace_custom_css .='.scrollup i{';
			$multivendor_marketplace_custom_css .='right: 100px;';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_theme_lay == 'Wide Width'){
		$multivendor_marketplace_custom_css .='body{';
			$multivendor_marketplace_custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$multivendor_marketplace_custom_css .='}';
		$multivendor_marketplace_custom_css .='.scrollup i{';
			$multivendor_marketplace_custom_css .='right: 30px;';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_theme_lay == 'Full Width'){
		$multivendor_marketplace_custom_css .='body{';
			$multivendor_marketplace_custom_css .='max-width: 100%;';
		$multivendor_marketplace_custom_css .='}';
	}

		/*---------------------------Blog Layout -------------------*/

	$multivendor_marketplace_theme_lay = get_theme_mod( 'multivendor_marketplace_blog_layout_option','Default');
    if($multivendor_marketplace_theme_lay == 'Default'){
		$multivendor_marketplace_custom_css .='.post-main-box{';
			$multivendor_marketplace_custom_css .='';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_theme_lay == 'Center'){
		$multivendor_marketplace_custom_css .='.post-main-box, .post-main-box h2, .post-info, .new-text p, .content-bttn{';
			$multivendor_marketplace_custom_css .='text-align:center;';
		$multivendor_marketplace_custom_css .='}';
		$multivendor_marketplace_custom_css .='.post-info{';
			$multivendor_marketplace_custom_css .='margin-top:10px;';
		$multivendor_marketplace_custom_css .='}';
		$multivendor_marketplace_custom_css .='.post-info hr{';
			$multivendor_marketplace_custom_css .='margin:15px auto;';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_theme_lay == 'Left'){
		$multivendor_marketplace_custom_css .='.post-main-box, .post-main-box h2, .post-info, .new-text p, .content-bttn, #our-services p{';
			$multivendor_marketplace_custom_css .='text-align:Left;';
		$multivendor_marketplace_custom_css .='}';
		$multivendor_marketplace_custom_css .='.post-info hr{';
			$multivendor_marketplace_custom_css .='margin-bottom:10px;';
		$multivendor_marketplace_custom_css .='}';
		$multivendor_marketplace_custom_css .='.post-main-box h2{';
			$multivendor_marketplace_custom_css .='margin-top:10px;';
		$multivendor_marketplace_custom_css .='}';
	}

	/*--------------------- Blog Page Posts -------------------*/

	$multivendor_marketplace_blog_page_posts_settings = get_theme_mod( 'multivendor_marketplace_blog_page_posts_settings','Into Blocks');
    if($multivendor_marketplace_blog_page_posts_settings == 'Without Blocks'){
		$multivendor_marketplace_custom_css .='.post-main-box{';
			$multivendor_marketplace_custom_css .='box-shadow: none; border: none; margin:30px 0;';
		$multivendor_marketplace_custom_css .='}';
	}

	/*---------------- Button Settings ------------------*/

	$multivendor_marketplace_button_padding_top_bottom = get_theme_mod('multivendor_marketplace_button_padding_top_bottom');
	$multivendor_marketplace_button_padding_left_right = get_theme_mod('multivendor_marketplace_button_padding_left_right');
	if($multivendor_marketplace_button_padding_top_bottom != false || $multivendor_marketplace_button_padding_left_right != false){
		$multivendor_marketplace_custom_css .='.post-main-box .more-btn a{';
			$multivendor_marketplace_custom_css .='padding-top: '.esc_attr($multivendor_marketplace_button_padding_top_bottom).'; padding-bottom: '.esc_attr($multivendor_marketplace_button_padding_top_bottom).';padding-left: '.esc_attr($multivendor_marketplace_button_padding_left_right).';padding-right: '.esc_attr($multivendor_marketplace_button_padding_left_right).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_button_border_radius = get_theme_mod('multivendor_marketplace_button_border_radius');
	if($multivendor_marketplace_button_border_radius != false){
		$multivendor_marketplace_custom_css .='.post-main-box .more-btn a{';
			$multivendor_marketplace_custom_css .='border-radius: '.esc_attr($multivendor_marketplace_button_border_radius).'px;';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_button_font_size = get_theme_mod('multivendor_marketplace_button_font_size',14);
	$multivendor_marketplace_custom_css .='.post-main-box .more-btn a, .more-btn i{';
		$multivendor_marketplace_custom_css .='font-size: '.esc_attr($multivendor_marketplace_button_font_size).';';
	$multivendor_marketplace_custom_css .='}';

	$multivendor_marketplace_theme_lay = get_theme_mod( 'multivendor_marketplace_button_text_transform','Uppercase');
	if($multivendor_marketplace_theme_lay == 'Capitalize'){
		$multivendor_marketplace_custom_css .='.post-main-box .more-btn a{';
			$multivendor_marketplace_custom_css .='text-transform:Capitalize;';
		$multivendor_marketplace_custom_css .='}';
	}
	if($multivendor_marketplace_theme_lay == 'Lowercase'){
		$multivendor_marketplace_custom_css .='.post-main-box .more-btn a{';
			$multivendor_marketplace_custom_css .='text-transform:Lowercase;';
		$multivendor_marketplace_custom_css .='}';
	}
	if($multivendor_marketplace_theme_lay == 'Uppercase'){
		$multivendor_marketplace_custom_css .='.post-main-box .more-btn a{';
			$multivendor_marketplace_custom_css .='text-transform:Uppercase;';
		$multivendor_marketplace_custom_css .='}';
	}	
	/*----------------Responsive Media -----------------------*/

	$multivendor_marketplace_resp_slider = get_theme_mod( 'multivendor_marketplace_resp_slider_hide_show',false);
	if($multivendor_marketplace_resp_slider == true && get_theme_mod( 'multivendor_marketplace_slider_hide_show', false) == false){
    	$multivendor_marketplace_custom_css .='#slider{';
			$multivendor_marketplace_custom_css .='display:none;';
		$multivendor_marketplace_custom_css .='} ';
	}
    if($multivendor_marketplace_resp_slider == true){
    	$multivendor_marketplace_custom_css .='@media screen and (max-width:575px) {';
		$multivendor_marketplace_custom_css .='#slider{';
			$multivendor_marketplace_custom_css .='display:block;';
		$multivendor_marketplace_custom_css .='} }';
	}else if($multivendor_marketplace_resp_slider == false){
		$multivendor_marketplace_custom_css .='@media screen and (max-width:575px) {';
		$multivendor_marketplace_custom_css .='#slider{';
			$multivendor_marketplace_custom_css .='display:none;';
		$multivendor_marketplace_custom_css .='} }';
		$multivendor_marketplace_custom_css .='@media screen and (max-width:575px){';
		$multivendor_marketplace_custom_css .='.page-template-custom-home-page.admin-bar .homepageheader{';
			$multivendor_marketplace_custom_css .='margin-top: 45px;';
		$multivendor_marketplace_custom_css .='} }';
	}

	$multivendor_marketplace_resp_sidebar = get_theme_mod( 'multivendor_marketplace_sidebar_hide_show',true);
    if($multivendor_marketplace_resp_sidebar == true){
    	$multivendor_marketplace_custom_css .='@media screen and (max-width:575px) {';
		$multivendor_marketplace_custom_css .='#sidebar{';
			$multivendor_marketplace_custom_css .='display:block;';
		$multivendor_marketplace_custom_css .='} }';
	}else if($multivendor_marketplace_resp_sidebar == false){
		$multivendor_marketplace_custom_css .='@media screen and (max-width:575px) {';
		$multivendor_marketplace_custom_css .='#sidebar{';
			$multivendor_marketplace_custom_css .='display:none;';
		$multivendor_marketplace_custom_css .='} }';
	}

	$multivendor_marketplace_resp_scroll_top = get_theme_mod( 'multivendor_marketplace_resp_scroll_top_hide_show',true);
	if($multivendor_marketplace_resp_scroll_top == true && get_theme_mod( 'multivendor_marketplace_hide_show_scroll',true) == false){
    	$multivendor_marketplace_custom_css .='.scrollup i{';
			$multivendor_marketplace_custom_css .='visibility:hidden !important;';
		$multivendor_marketplace_custom_css .='} ';
	}
    if($multivendor_marketplace_resp_scroll_top == true){
    	$multivendor_marketplace_custom_css .='@media screen and (max-width:575px) {';
		$multivendor_marketplace_custom_css .='.scrollup i{';
			$multivendor_marketplace_custom_css .='visibility:visible !important;';
		$multivendor_marketplace_custom_css .='} }';
	}else if($multivendor_marketplace_resp_scroll_top == false){
		$multivendor_marketplace_custom_css .='@media screen and (max-width:575px){';
		$multivendor_marketplace_custom_css .='.scrollup i{';
			$multivendor_marketplace_custom_css .='visibility:hidden !important;';
		$multivendor_marketplace_custom_css .='} }';
	}

	$multivendor_marketplace_resp_menu_toggle_btn_bg_color = get_theme_mod('multivendor_marketplace_resp_menu_toggle_btn_bg_color');
	if($multivendor_marketplace_resp_menu_toggle_btn_bg_color != false){
		$multivendor_marketplace_custom_css .='.toggle-nav i{';
			$multivendor_marketplace_custom_css .='background: '.esc_attr($multivendor_marketplace_resp_menu_toggle_btn_bg_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	/*-------------- Copyright Alignment ----------------*/

	$multivendor_marketplace_copyright_alingment = get_theme_mod('multivendor_marketplace_copyright_alingment');
	if($multivendor_marketplace_copyright_alingment != false){
		$multivendor_marketplace_custom_css .='.copyright p{';
			$multivendor_marketplace_custom_css .='text-align: '.esc_attr($multivendor_marketplace_copyright_alingment).';';
		$multivendor_marketplace_custom_css .='}';
	}

	/*------------------ Logo  -------------------*/

	$multivendor_marketplace_site_title_font_size = get_theme_mod('multivendor_marketplace_site_title_font_size');
	if($multivendor_marketplace_site_title_font_size != false){
		$multivendor_marketplace_custom_css .='.logo h1, .logo p.site-title{';
			$multivendor_marketplace_custom_css .='font-size: '.esc_attr($multivendor_marketplace_site_title_font_size).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_site_tagline_font_size = get_theme_mod('multivendor_marketplace_site_tagline_font_size');
	if($multivendor_marketplace_site_tagline_font_size != false){
		$multivendor_marketplace_custom_css .='.logo p.site-description{';
			$multivendor_marketplace_custom_css .='font-size: '.esc_attr($multivendor_marketplace_site_tagline_font_size).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_logo_padding = get_theme_mod('multivendor_marketplace_logo_padding');
	if($multivendor_marketplace_logo_padding != false){
		$multivendor_marketplace_custom_css .='.middle-header .logo{';
			$multivendor_marketplace_custom_css .='padding: '.esc_attr($multivendor_marketplace_logo_padding).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_logo_margin = get_theme_mod('multivendor_marketplace_logo_margin');
	if($multivendor_marketplace_logo_margin != false){
		$multivendor_marketplace_custom_css .='.middle-header .logo{';
			$multivendor_marketplace_custom_css .='margin: '.esc_attr($multivendor_marketplace_logo_margin).';';
		$multivendor_marketplace_custom_css .='}';
	}

		/*-------------- Copyright Alignment ----------------*/

	$multivendor_marketplace_footer_widgets_heading = get_theme_mod( 'multivendor_marketplace_footer_widgets_heading','Left');
    if($multivendor_marketplace_footer_widgets_heading == 'Left'){
		$multivendor_marketplace_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
		$multivendor_marketplace_custom_css .='text-align: left;';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_footer_widgets_heading == 'Center'){
		$multivendor_marketplace_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$multivendor_marketplace_custom_css .='text-align: center;';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_footer_widgets_heading == 'Right'){
		$multivendor_marketplace_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$multivendor_marketplace_custom_css .='text-align: right;';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_footer_widgets_content = get_theme_mod( 'multivendor_marketplace_footer_widgets_content','Left');
    if($multivendor_marketplace_footer_widgets_content == 'Left'){
		$multivendor_marketplace_custom_css .='#footer .widget{';
		$multivendor_marketplace_custom_css .='text-align: left;';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_footer_widgets_content == 'Center'){
		$multivendor_marketplace_custom_css .='#footer .widget{';
			$multivendor_marketplace_custom_css .='text-align: center;';
		$multivendor_marketplace_custom_css .='}';
	}else if($multivendor_marketplace_footer_widgets_content == 'Right'){
		$multivendor_marketplace_custom_css .='#footer .widget{';
			$multivendor_marketplace_custom_css .='text-align: right;';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_copyright_alingment = get_theme_mod('multivendor_marketplace_copyright_alingment');
	if($multivendor_marketplace_copyright_alingment != false){
		$multivendor_marketplace_custom_css .='.copyright p{';
			$multivendor_marketplace_custom_css .='text-align: '.esc_attr($multivendor_marketplace_copyright_alingment).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_footer_padding = get_theme_mod('multivendor_marketplace_footer_padding');
	if($multivendor_marketplace_footer_padding != false){
		$multivendor_marketplace_custom_css .='#footer{';
			$multivendor_marketplace_custom_css .='padding: '.esc_attr($multivendor_marketplace_footer_padding).' 0;';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_footer_icon = get_theme_mod('multivendor_marketplace_footer_icon');
	if($multivendor_marketplace_footer_icon == false){
		$multivendor_marketplace_custom_css .='.copyright p{';
			$multivendor_marketplace_custom_css .='width:100%; text-align:center; float:none;';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_footer_background_image = get_theme_mod('multivendor_marketplace_footer_background_image');
	if($multivendor_marketplace_footer_background_image != false){
		$multivendor_marketplace_custom_css .='#footer{';
			$multivendor_marketplace_custom_css .='background: url('.esc_attr($multivendor_marketplace_footer_background_image).');';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_footer_background_color = get_theme_mod('multivendor_marketplace_footer_background_color');
	if($multivendor_marketplace_footer_background_color != false){
		$multivendor_marketplace_custom_css .='#footer{';
			$multivendor_marketplace_custom_css .='background-color: '.esc_attr($multivendor_marketplace_footer_background_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	/*------------- Preloader Background Color  -------------------*/

	$multivendor_marketplace_preloader_bg_color = get_theme_mod('multivendor_marketplace_preloader_bg_color');
	if($multivendor_marketplace_preloader_bg_color != false){
		$multivendor_marketplace_custom_css .='#preloader{';
			$multivendor_marketplace_custom_css .='background-color: '.esc_attr($multivendor_marketplace_preloader_bg_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_preloader_border_color = get_theme_mod('multivendor_marketplace_preloader_border_color');
	if($multivendor_marketplace_preloader_border_color != false){
		$multivendor_marketplace_custom_css .='.loader-line{';
			$multivendor_marketplace_custom_css .='border-color: '.esc_attr($multivendor_marketplace_preloader_border_color).'!important;';
		$multivendor_marketplace_custom_css .='}';
	}

		/*------------------ Menus -------------------*/

	$multivendor_marketplace_header_menus_color = get_theme_mod('multivendor_marketplace_header_menus_color');
	if($multivendor_marketplace_header_menus_color != false){
		$multivendor_marketplace_custom_css .='.main-navigation a{';
			$multivendor_marketplace_custom_css .='color: '.esc_attr($multivendor_marketplace_header_menus_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_header_menus_hover_color = get_theme_mod('multivendor_marketplace_header_menus_hover_color');
	if($multivendor_marketplace_header_menus_hover_color != false){
		$multivendor_marketplace_custom_css .='.main-navigation a:hover{';
			$multivendor_marketplace_custom_css .='color: '.esc_attr($multivendor_marketplace_header_menus_hover_color).'!important;';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_header_submenus_color = get_theme_mod('multivendor_marketplace_header_submenus_color');
	if($multivendor_marketplace_header_submenus_color != false){
		$multivendor_marketplace_custom_css .='.main-navigation ul ul a{';
			$multivendor_marketplace_custom_css .='color: '.esc_attr($multivendor_marketplace_header_submenus_color).';';
		$multivendor_marketplace_custom_css .='}';
	}

	$multivendor_marketplace_header_submenus_hover_color = get_theme_mod('multivendor_marketplace_header_submenus_hover_color');
	if($multivendor_marketplace_header_submenus_hover_color != false){
		$multivendor_marketplace_custom_css .='.main-navigation ul.sub-menu a:hover{';
			$multivendor_marketplace_custom_css .='color: '.esc_attr($multivendor_marketplace_header_submenus_hover_color).'!important;';
		$multivendor_marketplace_custom_css .='}';
	}

	/*--------------------------- Slider Opacity -------------------*/

	$multivendor_marketplace_theme_lay = get_theme_mod( 'multivendor_marketplace_slider_opacity_color','0.4');
	if($multivendor_marketplace_theme_lay == '0'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.1'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.1';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.2'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.2';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.3'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.3';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.4'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.4';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.5'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.5';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.6'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.6';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.7'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.7';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.8'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.8';
		$multivendor_marketplace_custom_css .='}';
		}else if($multivendor_marketplace_theme_lay == '0.9'){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='opacity:0.9';
		$multivendor_marketplace_custom_css .='}';
		}

	/*---------------------------Slider Height ------------*/

	$multivendor_marketplace_slider_height = get_theme_mod('multivendor_marketplace_slider_height');
	if($multivendor_marketplace_slider_height != false){
		$multivendor_marketplace_custom_css .='#slider img{';
			$multivendor_marketplace_custom_css .='height: '.esc_attr($multivendor_marketplace_slider_height).';';
		$multivendor_marketplace_custom_css .='}';
	}
