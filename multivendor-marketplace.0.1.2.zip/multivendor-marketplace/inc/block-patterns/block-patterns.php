<?php
/**
 *  Multivendor Marketplace: Block Patterns
 *
 * @package  Multivendor Marketplace
 * @since   1.0.0
 */

/**
 * Register Block Pattern Category.
 */
if ( function_exists( 'register_block_pattern_category' ) ) {

	register_block_pattern_category(
		'multivendor-marketplace',
		array( 'label' => __( 'Multivendor Marketplace', 'multivendor-marketplace' ) )
	);
}

/**
 * Register Block Patterns.
 */
if ( function_exists( 'register_block_pattern' ) ) {
	register_block_pattern(
		'multivendor-marketplace/banner-section',
		array(
			'title'      => __( 'Banner Section', 'multivendor-marketplace' ),
			'categories' => array( 'multivendor-marketplace' ),
			'content'    => "<!-- wp:columns {\"className\":\"multivendor-banner-section\"} -->\n<div class=\"wp-block-columns multivendor-banner-section\"><!-- wp:column {\"width\":\"66.66%\",\"className\":\"multivendor-banner-read-more-section\"} -->\n<div class=\"wp-block-column multivendor-banner-read-more-section\" style=\"flex-basis:66.66%\"><!-- wp:cover {\"url\":\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/banner-image.png\",\"id\":3555,\"dimRatio\":0,\"isDark\":false} -->\n<div class=\"wp-block-cover is-light\"><span aria-hidden=\"true\" class=\"wp-block-cover__background has-background-dim-0 has-background-dim\"></span><img class=\"wp-block-cover__image-background wp-image-3555\" alt=\"\" src=\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/banner-image.png\" data-object-fit=\"cover\"/><div class=\"wp-block-cover__inner-container\"><!-- wp:columns {\"className\":\"px-5 \"} -->\n<div class=\"wp-block-columns px-5\"><!-- wp:column {\"width\":\"80%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:80%\"><!-- wp:heading {\"level\":1,\"style\":{\"typography\":{\"fontSize\":\"35px\"}},\"textColor\":\"white\"} -->\n<h1 class=\"has-white-color has-text-color\" style=\"font-size:35px\">A revolution in recognition</h1>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph {\"textColor\":\"white\"} -->\n<p class=\"has-white-color has-text-color\">lorem ipsum&nbsp;is simply dummy text of the printing and typesetting industry.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class=\"wp-block-buttons\"><!-- wp:button {\"backgroundColor\":\"white\",\"style\":{\"color\":{\"text\":\"#ff636b\"},\"border\":{\"radius\":\"18px\"},\"typography\":{\"fontSize\":\"12px\"}}} -->\n<div class=\"wp-block-button has-custom-font-size\" style=\"font-size:12px\"><a class=\"wp-block-button__link has-white-background-color has-text-color has-background wp-element-button\" style=\"border-radius:18px;color:#ff636b\">Read More</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"33.33%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:33.33%\"></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div></div>\n<!-- /wp:cover --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"33.33%\",\"className\":\"multivendor-banner-buy-now-section\"} -->\n<div class=\"wp-block-column multivendor-banner-buy-now-section\" style=\"flex-basis:33.33%\"><!-- wp:cover {\"url\":\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/banner-image-1.png\",\"id\":3557,\"dimRatio\":0,\"isDark\":false} -->\n<div class=\"wp-block-cover is-light\"><span aria-hidden=\"true\" class=\"wp-block-cover__background has-background-dim-0 has-background-dim\"></span><img class=\"wp-block-cover__image-background wp-image-3557\" alt=\"\" src=\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/banner-image-1.png\" data-object-fit=\"cover\"/><div class=\"wp-block-cover__inner-container\"><!-- wp:heading {\"textAlign\":\"center\",\"style\":{\"typography\":{\"fontSize\":\"26px\"}}} -->\n<h2 class=\"has-text-align-center\" style=\"font-size:26px\">shop to get what you love</h2>\n<!-- /wp:heading -->\n\n<!-- wp:buttons -->\n<div class=\"wp-block-buttons\"><!-- wp:button {\"align\":\"center\",\"style\":{\"typography\":{\"fontSize\":\"14px\"}},\"className\":\"is-style-fill\"} -->\n<div class=\"wp-block-button aligncenter has-custom-font-size is-style-fill\" style=\"font-size:14px\"><a class=\"wp-block-button__link wp-element-button\">Buy Now</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div></div>\n<!-- /wp:cover --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns -->",
		)
	);

	register_block_pattern(
		'multivendor-marketplace/products-section',
		array(
			'title'      => __( 'Products Section', 'multivendor-marketplace' ),
			'categories' => array( 'multivendor-marketplace' ),
			'content'    => "<!-- wp:group {\"className\":\"multivendor-selling-section mt-5\",\"layout\":{\"type\":\"constrained\"}} -->\n<div class=\"wp-block-group multivendor-selling-section mt-5\"><!-- wp:heading {\"style\":{\"typography\":{\"fontSize\":\"35px\"}}} -->\n<h2 style=\"font-size:35px\">Best Sellings Products</h2>\n<!-- /wp:heading -->\n\n<!-- wp:columns {\"className\":\"pt-5\"} -->\n<div class=\"wp-block-columns pt-5\"><!-- wp:column {\"width\":\"30.33%\",\"className\":\"multivendor-deal-section\"} -->\n<div class=\"wp-block-column multivendor-deal-section\" style=\"flex-basis:30.33%\"><!-- wp:cover {\"url\":\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/product-image.png\",\"id\":3682,\"dimRatio\":0,\"isDark\":false,\"fontSize\":\"small\"} -->\n<div class=\"wp-block-cover is-light has-small-font-size\"><span aria-hidden=\"true\" class=\"wp-block-cover__background has-background-dim-0 has-background-dim\"></span><img class=\"wp-block-cover__image-background wp-image-3682\" alt=\"\" src=\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/product-image.png\" data-object-fit=\"cover\"/><div class=\"wp-block-cover__inner-container\"><!-- wp:paragraph {\"textColor\":\"black\",\"fontSize\":\"medium\"} -->\n<p class=\"has-black-color has-text-color has-medium-font-size\">Get Great Deals On Handbags</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:cover --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"70.66%\",\"className\":\"product-section\"} -->\n<div class=\"wp-block-column product-section\" style=\"flex-basis:70.66%\"><!-- wp:woocommerce/product-category {\"columns\":4,\"rows\":1,\"categories\":[19],\"contentVisibility\":{\"title\":true,\"price\":true,\"rating\":true,\"button\":true}} /--></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div>\n<!-- /wp:group -->",
		)
	);
}